#importing
import tkinter as tk
from tkinter import *
root = tk()
from tkinter import textbox
from Dronedogs (1) import image
# create new window
        self.lblTitle = tk.Label()
        self.lblBeefDogs = tk.Label()
        self.Label2 = tk.Label()
        self.lblTurkeyDogs = tk.Label()
        self.txtBeefDogs = tk.TextBox()
        self.txtPorkDogs = tk.TextBox()
        self.txtTurkeyDogs = tk.TextBox()
        self.lblSalesTax = tk.Label()
        self.lblTotalCost = tk.Label()
        self.txtSubtotal = tk.TextBox()
        self.txtSalesTax = tk.TextBox()
        self.txtTotalCost = tk.TextBox()
        self.picLogo = tk.PictureBox()
        self.btnCalculate = tk.Button()
        self.Button3 = tk.Button()
        self.btnSubmit = tk.Button()
        CType(Me.picLogo).BeginInit()
        self.SuspendLayout()
        #Creating a title widget
        'lblTitle
        '
        self.lblTitle.AutoSize = True
        self.lblTitle.Font = root.Font("Microsoft Sans Serif", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        self.lblTitle.ForeColor = root.Color.Maroon
        self.lblTitle.Location = root.Point(64, 24)
        self.lblTitle.Name = "lblTitle"
        self.lblTitle.Size = root.Size(196,20)
        self.lblTitle.TabIndex = 0
        self.lblTitle.Text = "DroneDogs Order Form"
        #create label widget
        'lblBeefDogs
        '
        self.lblBeefDogs.AutoSize = True
        self.lblBeefDogs.Location = root.Point(38, 60)
        self.lblBeefDogs.Name = "lblBeefDogs"
        self.lblBeefDogs.Size = root.Size(64, 13)
        self.lblBeefDogs.TabIndex = 1
        self.lblBeefDogs.Text = "# BeefDogs"
        '
        'Label2
        '
        self.Label2.AutoSize = True
        self.Label2.Location = root.Point(38, 87)
        self.Label2.Name = "Label2"
        self.Label2.Size = root.Size(67, 13)
        self.Label2.TabIndex = 2
        self.Label2.Text = "# PorkDogs:"
        '
        'lblTurkeyDogs
        '
        self.lblTurkeyDogs.AutoSize = True
        self.lblTurkeyDogs.Location = root.Point(38, 113)
        self.lblTurkeyDogs.Name = "lblTurkeyDogs"
        self.lblTurkeyDogs.Size = root.Size(78, 13)
        self.lblTurkeyDogs.TabIndex = 3
        self.lblTurkeyDogs.Text = "# TurkeyDogs:"
        Creating textbox widget
        'txtBeefDogs
        '
        self.txtBeefDogs.Location = root.Point(122, 60)
        self.txtBeefDogs.Name = "txtBeefDogs"
        self.txtBeefDogs.Size = root.Size(40, 20)
        self.txtBeefDogs.TabIndex = 4
        '
        'txtPorkDogs
        '
        self.txtPorkDogs.Location = root.Point(122, 87)
        self.txtPorkDogs.Name = "txtPorkDogs"
        self.txtPorkDogs.Size = root.Size(40, 20)
        self.txtPorkDogs.TabIndex = 5
        '
        'txtTurkeyDogs
        '
        self.txtTurkeyDogs.Location = root.Point(122, 113)
        self.txtTurkeyDogs.Name = "txtTurkeyDogs"
        self.txtTurkeyDogs.Size = root.Size(40, 20)
        self.txtTurkeyDogs.TabIndex = 6
        '
        'lblSalesTax
        '
        self.lblSalesTax.AutoSize = True
        self.lblSalesTax.Location = root.Point(41, 231)
        self.lblSalesTax.Name = "lblSalesTax"
        self.lblSalesTax.Size = root.Size(57, 13)
        self.lblSalesTax.TabIndex = 8
        self.lblSalesTax.Text = "Sales Tax:"
        '
        'lblTotalCost
        '
        self.lblTotalCost.AutoSize = True
        self.lblTotalCost.Location = root.Point(41, 258)
        self.lblTotalCost.Name = "lblTotalCost"
        self.lblTotalCost.Size = root.Size(58, 13)
        self.lblTotalCost.TabIndex = 9
        self.lblTotalCost.Text = "Total Cost:"
        '
        'txtSubtotal
        '
        self.txtSubtotal.Location = root.Point(122, 205)
        self.txtSubtotal.Name = "txtSubtotal"
        self.txtSubtotal.Size = root.Size(100, 20)
        self.txtSubtotal.TabIndex = 10
        '
        'txtSalesTax
        '
        self.txtSalesTax.Location = root.Point(122, 231)
        self.txtSalesTax.Name = "txtSalesTax"
        self.txtSalesTax.Size = root.Size(100, 20)
        self.txtSalesTax.TabIndex = 11
        '
        'txtTotalCost
        '
        self.txtTotalCost.Location = root.Point(122, 258)
        self.txtTotalCost.Name = "txtTotalCost"
        self.txtTotalCost.Size = root.Size(100, 20)
        self.txtTotalCost.TabIndex = 12
        '
        'picLogo
        '
        self.picLogo.Image = CType(resources.GetObject("picLogo.Image"), root.Image)
        self.picLogo.Location = New System.Drawing.Point(294, 9)
        self.picLogo.Name = "picLogo"
        self.picLogo.Size = root.Size(88, 98)Image
        self.picLogo.TabIndex = 13
        self.picLogo.TabStop = False
        #Creatimg button widgett
        'btnCalculate
        '
        self.btnCalculate.Location = root.Point(30, 157)
        self.btnCalculate.Name = "btnCalculate"
        self.btnCalculate.Size = root.Size(89, 23)
        self.btnCalculate.TabIndex = 14
        self.btnCalculate.Text = "Calculate Order"
        self.btnCalculate.UseVisualStyleBackColor = True
        '
        'Button3
        '
        self.Button3.Location = root.Point(232, 157)
        self.Button3.Name = "Button3"
        self.Button3.Size = root.Size(89, 23)
        self.Button3.TabIndex = 15
        self.Button3.Text = "EXIT?"
        self.Button3.UseVisualStyleBackColor = True
        '
        'btnSubmit
        '
        self.btnSubmit.Location = root.Point(131, 157)
        self.btnSubmit.Name = "btnSubmit"
        self.btnSubmit.Size = .Size(89, 23)
        self.btnSubmit.TabIndex = 16
        self.btnSubmit.Text = "Submit Order"
        self.btnSubmit.UseVisualStyleBackColor = True
        '
        'DroneDogsOrder
        '
        self.AutoScaleDimensions = root.SizeF(6.0!, 13.0!)
        self.ClientSize = root.Size(394, 419)
        self.Controls.Add(Me.btnSubmit)
        self.Controls.Add(Me.Button3)
        self.Controls.Add(Me.btnCalculate)
        self.Controls.Add(Me.picLogo)
        self.Controls.Add(Me.txtTotalCost)
        self.Controls.Add(Me.txtSalesTax)
        self.Controls.Add(Me.txtSubtotal)
        self.Controls.Add(Me.lblTotalCost)
        self.Controls.Add(Me.lblSalesTax)
        self.Controls.Add(Me.txtTurkeyDogs)
        self.Controls.Add(Me.txtPorkDogs)
        self.Controls.Add(Me.txtBeefDogs)
        self.Controls.Add(Me.lblTurkeyDogs)
        self.Controls.Add(Me.Label2)
        self.Controls.Add(Me.lblBeefDogs)
        self.Controls.Add(Me.lblTitle)
        self.Name = "DroneDogsOrder"
        self.Text = "No Name"
        CType(Me.picLogo).EndInit()
        self.ResumeLayout(False)
        self.PerformLayout()

