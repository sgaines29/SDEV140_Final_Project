     Public Sub CreateCustomer(firstName As String, lastName As String, email As String)
        'Declare a customer object
        Dim objNewCustomer As Customer

        'Create the new customer
        objNewCustomer.FirstName = firstName
        objNewCustomer.LastName = lastName
        objNewCustomer.Email = email

        'Add the new customer to the list
        objCustomers.Add(objNewCustomer)

        'Add the new customer to the ListBox control
        lstCustomers.Items.Add(objNewCustomer)
        
    CreateCustomer("Fred", "Garvin", "fgarvin@thiscompanysnl.com")
    CreateCustomer("Fran", "Pepper", "fpepper@notthesoftdrink.org")
    CreateCustomer("Will", "Robinson", "wrobinson@lostinspacetown.gov")

     End Sub
         Public ReadOnly Property SelectedCustomer() As Customer
        Get
            If lstCustomers.SelectedIndex <> -1 Then
                'Return this customer
                Return CType(objCustomers(lstCustomers.SelectedIndex), Customer)
            End If
        End Get
    End Property

